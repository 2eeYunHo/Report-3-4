#include <stdio.h>
#include <stdlib.h>

int menu_display(void);
int sub_menu_display01(void); //
int sub_menu_display02(void); //
void sub_main01(void); //
void sub_main02(void); //

void cheeze(void);  //       메뉴1에 들어갔을때 2or1
void sweetpotato(void);   //
void yangnum(void);             //         메뉴1이후에 세트or단품
void fride(void);               //         
void press_any_key(void);  //아무키나 누르면 이전 메뉴로 

int main(void)
{
	    int c;
	        while((c=menu_display())!=3)
			    {
				            switch(c)
						            {
								               case 1 : sub_main01();
											           break;
											           case 2 : sub_main02();
													               break;
													               default : break;
																         }
					        }
		 return 0;
}
int menu_display(void)
{
	    int select;
	        system("cls");
		    printf("메인메뉴를 선택하시오\n\n");
		        printf("1. 피자 \n");
			    printf("2. 치킨\n");
			        printf("3. 프로그램 종료\n\n");
				    printf("메뉴번호 입력>");
				        select=getchar()-48;
					    return select;
}
void sub_main01(void)
{
	    int c;
	        while((c=sub_menu_display01())!= 3)
			    {
				          switch(c)
						        {
								           case 1 : cheeze();
										                  break;
										               case 2 : sweetpotato();
													             break;
													           default : break;
															          }
					     }
}

int sub_menu_display01(void)
{
	    int select;
	        system("cls");
		    printf("피자맛을 고르시오?\n\n");
		        printf("1. CHEEEEEZZZZZZE\n");
			    printf("2. SWEETPOTATO\n");
			        printf("3. 메인 메뉴로 이동\n\n");
				    printf("메뉴번호 입력>");
				        select=getchar()-48;
					    return select;
}
void cheeze(void)
{
	   system("cls");
	      printf("치즈 피자를 하셨습니다\n");
	         printf("중략\n");
		    press_any_key();
}

void sweetpotato(void)
{
	   system("cls");
	      printf("고구마 피자를 하셨습니다\n");
	         printf("중략\n");
		    press_any_key();
}

void sub_main02(void)
{
	    int c;
	        while((c=sub_menu_display02())!= 3)
			    {
				          switch(c)
						        {
								           case 1 : yangnum();
										                  break;
										               case 2 : fride();
													             break;
													           default : break;
															          }
					     }
}
int sub_menu_display02(void)
{
	        int select;
		        system("cls");
			        printf("양념을 하시겠습니까?\n\n");
				        printf("1. YEEEEEEEEEEEES \n");
					        printf("2. NOOOOOOOOO\n");
						        printf("3. 메인 메뉴로 이동\n\n");
							        printf("메뉴번호 입력>");
								        select=getchar()-48;
									        return select;
}

void yangnum (void)
{
	   system("cls");
	      printf("양념치킨을 하셨습니다.\n");
	         printf("중략\n");
		    press_any_key();
}

void fride(void)
{
	   system("cls");
	      printf("후라이드치킨을 하셨습니다.\n");
	         printf("중략\n");
		    press_any_key();
}

void press_any_key(void)
{
	       printf("\n\n");
	              printf("아무키나 누르면 이전 메뉴로...");
		             getchar();
}
