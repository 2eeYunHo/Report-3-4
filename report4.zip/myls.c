#include <stdio.h>
#include <dirent.h>

void listdir(char *pth)
{
	    DIR *dp; // 디렉토리 불러오기
	        struct dirent *ep;
		    char *np;

		        dp = opendir(pth);
			    while (1) {
				            ep = readdir(dp);
					            if (ep == NULL) break;
						            np = ep->d_name;
							            puts(np);
								        }
			        closedir(dp);
}

int main()
{
	    listdir(".");// 확장자를 표시하기위한 코드
	        return 0;
}
// 출처: : https://kldp.org/node/33892 feanor님의 코드
